#include <stdio.h>
#include <stdlib.h>
#include "Empleados.h"


int menuDeOpciones(char[]);



int main()
{
    int tam =3;
    int opcioon;
    eEmpleado lista[3];

    inicializarEmpleados(lista,tam);

    do
    {
        opcioon = menuDeOpciones("1.ALTA /2. BAJA /n3. Modificar/4.Mostrar /5.Salir");
        switch(opcioon)
        {
        case 1:
            cargarEmpleados(lista,tam);
        break;

        case 4:
            mostrarEmpleados(lista,tam);
        break;
        }
    }while(opcioon != 5);



    //inicializarEmpleados(lista,tam);

    cargarEmpleados(lista,tam);

    mostrarEmpleados(lista,tam);



    return 0;
}



int menuDeOpciones(char mensaje[])
{
int opcion;
printf("%s", mensaje);
scanf("%d",opcion);
return opcion;
}
