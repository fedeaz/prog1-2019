#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int legajo;
    char nombre[20];
    char sexo;
    float sueldo;
    int esado;
}eEmpleado;

void mostrarEmpleado(eEmpleado);
void cargarEmpleados(eEmpleado[],int);
void mostrarEmpleados(eEmpleado[],int);
int pedirEntero(int);
int buscarLibre(eEmpleado[],int);
void inicializarEmpleados(eEmpleado[],int);
int buscarUno(eEmpleado[],int,int);
int borrarUno(eEmpleado[],int,int);


int main()
{
    int tam =3;
    eEmpleado lista[3];

    inicializarEmpleados(lista,tam);

    cargarEmpleados(lista,tam);

    mostrarEmpleados(lista,tam);




    return 0;
}

void mostrarEmpleado(eEmpleado emp)
{
    printf("%d-%s-%c-%f-%d\n",emp.legajo,emp.nombre,emp.sexo,emp.sueldo, emp.esado);
}

void cargarEmpleados(eEmpleado emp[],int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        printf("ingrese legajo\n");
        scanf("%d",&emp[i].legajo);
        printf("ingrese el nombre\n");
        fflush(stdin);
        gets(emp[i].nombre);
        printf("ingrese el sexo\n");
        fflush(stdin);
        scanf("%c",&emp[i].sexo);
        fflush(stdin);
        printf("ingrese el sueldo\n");
        scanf("%f",&emp[i].sueldo);
    }
}

void mostrarEmpleados(eEmpleado emp[],int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        printf("%d-%s-%c-%.2f-%d\n",emp[i].legajo,emp[i].nombre,emp[i].sexo,emp[i].sueldo,emp[i].esado);
    }
}

int pedirEntero(int entero)
{
    if(entero <=100&&entero >=0)
    {
        return entero;
    }
    else
    {
        return 0;
    }
}

void inicializarEmpleados(eEmpleado lista[],int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        lista[i].esado = 0;
    }
}

int buscarLibre(eEmpleado lista[],int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        if(lista[i].esado == 0)
        {
            return lista[i].legajo;
        }
        else
        {
            return -1;
        }
    }
}

int buscarUno(eEmpleado lista[],int tam,int legajo)
{
    int i;
    for(i=0;i<tam;i++)
    {
      if(legajo == lista[i].legajo)
      {
          return lista[i].legajo;
      }
      else
      {
          return -1;
      }
    }
}

int borrarUno(eEmpleado lista[], int tam, int legajo)
{
    int i;
    for(i=0;i<tam;i++)
    {
    if(buscarUno(lista,tam,legajo) != -1)
    {
        lista[i].esado == 0;
        return 1;
    }
    else
        return 0;

    }


}
